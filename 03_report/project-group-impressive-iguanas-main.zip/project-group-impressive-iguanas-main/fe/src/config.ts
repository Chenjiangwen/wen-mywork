const config = {
    client_id: process.env.REACT_APP_CLIENT_ID,
    gateway_endpoint: process.env.REACT_APP_GATEWAY_ENDPOINT,
}

export default config
