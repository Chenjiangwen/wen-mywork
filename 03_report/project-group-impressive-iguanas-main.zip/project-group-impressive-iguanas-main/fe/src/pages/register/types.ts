interface RegisterRequest {
    project: string
}

export type { RegisterRequest }
