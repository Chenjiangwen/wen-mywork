interface User {
    token: string
    tokenType: string
    email: string
}

export type { User }
