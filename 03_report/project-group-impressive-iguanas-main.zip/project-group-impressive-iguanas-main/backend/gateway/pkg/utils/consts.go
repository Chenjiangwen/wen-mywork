package utils

const USER_SERVICE string = "userServiceAddr"

const FEATUREFLAG_SERVICE string = "featureflagServiceAddr"

const FEATUREFLAG_WRITE_SERVICE string = "featureflagWriteServiceAddr"
