package consts

const JWT_KEY string = "featuresflyKey"
const ISS string = "featuresfly"
const TOKEN_TYPE string = "Berear"
const USER_JWT_KEY string = "userJwtKey"
