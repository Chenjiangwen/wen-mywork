package consts

const JWT_KEY string = "featuresflyKey"
const ISS string = "featuresfly"
const TOKEN_TYPE string = "Berear"
const USER_JWT_KEY string = "userJwtKey"

const DB_USER_COLLECTION string = "users"
const DB_PROJECT_ID_COLLECTION string = "projectid"
const MONGODB string = "mongodb"
