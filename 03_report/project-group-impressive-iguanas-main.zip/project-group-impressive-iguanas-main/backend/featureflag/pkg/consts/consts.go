package consts

const JWT_KEY string = "featuresflyKey"
const ISS string = "featuresfly"
const USER_JWT_KEY string = "userJwtKey"
const MONGODB string = "mongodb"

const ADMIN_COLLECTION string = "collection"

const ADMIN_FEATUREFLAG string = "featureflag"
